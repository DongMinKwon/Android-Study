package com.example.week112017313135

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
