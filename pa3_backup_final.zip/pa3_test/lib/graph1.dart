import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:pa3_test/main.dart';


LineChartData graph1() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr1 = <FlSpot>[];

  for(int i = 0; i<7; i++){
    spotsGr1.add(FlSpot(i.toDouble(), (dateTotalList[6-i]/1000000000 - 5.25)/0.25));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '5.5B';
            case 3:
              return '6.0B';
            case 5:
              return '6.5B';
            case 7:
              return '7.0B';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[6].substring(5);
            case 1:
              return dateList[5].substring(5);
            case 2:
              return dateList[4].substring(5);
            case 3:
              return dateList[3].substring(5);
            case 4:
              return dateList[2].substring(5);
            case 5:
              return dateList[1].substring(5);
            case 6:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
      show: true,
        border: Border.all(width: 0)),
      minX: 0,
      maxX: 6,
      minY: 0,
      maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr1,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
          show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 4,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph2() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr2 = <FlSpot>[];

  for(int i = 0; i<7; i++){
    spotsGr2.add(FlSpot(i.toDouble(), (dateDailyList[6-i]/1000000 - 85)/5));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '90.0M';
            case 3:
              return '100.0M';
            case 5:
              return '110.0M';
            case 7:
              return '120.0M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[6].substring(5);
            case 1:
              return dateList[5].substring(5);
            case 2:
              return dateList[4].substring(5);
            case 3:
              return dateList[3].substring(5);
            case 4:
              return dateList[2].substring(5);
            case 5:
              return dateList[1].substring(5);
            case 6:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 6,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr2,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
          show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 4,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph3() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr3 = <FlSpot>[];

  for(int i = 0; i<29; i++){
    spotsGr3.add(FlSpot(i.toDouble(), (dateTotalList[28-i]/1000000000 - 3.5)/0.5));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '4.0B';
            case 3:
              return '5.0B';
            case 5:
              return '6.0B';
            case 7:
              return '7.0B';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[28].substring(5);
            case 7:
              return dateList[21].substring(5);
            case 14:
              return dateList[14].substring(5);
            case 21:
              return dateList[7].substring(5);
            case 28:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 28,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr3,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
          show: true,
          getDotPainter: (spot, p, data, i){
            return FlDotCirclePainter(
              radius: 2,
              color: Color(0xff49B7Eb)
            );
          }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph4() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr4 = <FlSpot>[];

  for(int i = 0; i<29; i++){
    spotsGr4.add(FlSpot(i.toDouble(), (dateDailyList[28-i]/1000000 - 50)/10));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '60.6M';
            case 3:
              return '80.0M';
            case 5:
              return '100.0M';
            case 7:
              return '120.0M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[28].substring(5);
            case 7:
              return dateList[21].substring(5);
            case 14:
              return dateList[14].substring(5);
            case 21:
              return dateList[7].substring(5);
            case 28:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 28,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr4,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
          show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 2,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph5() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr1 = <FlSpot>[];

  for(int i = 0; i<7; i++){
    spotsGr1.add(FlSpot(i.toDouble(), (dateTotalCaseList[6-i]/1000000 - 515)/3));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '518.0M';
            case 3:
              return '524.0M';
            case 5:
              return '530.0M';
            case 7:
              return '536.0M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[6].substring(5);
            case 1:
              return dateList[5].substring(5);
            case 2:
              return dateList[4].substring(5);
            case 3:
              return dateList[3].substring(5);
            case 4:
              return dateList[2].substring(5);
            case 5:
              return dateList[1].substring(5);
            case 6:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 6,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr1,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
            show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 4,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph6() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr2 = <FlSpot>[];

  for(int i = 0; i<7; i++){
    spotsGr2.add(FlSpot(i.toDouble(), (dateNewCaseList[6-i]/1000000 - 1.4)/0.1));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '1.5M';
            case 3:
              return '1.7M';
            case 5:
              return '1.9M';
            case 7:
              return '2.1M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[6].substring(5);
            case 1:
              return dateList[5].substring(5);
            case 2:
              return dateList[4].substring(5);
            case 3:
              return dateList[3].substring(5);
            case 4:
              return dateList[2].substring(5);
            case 5:
              return dateList[1].substring(5);
            case 6:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 6,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr2,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
            show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 4,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph7() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr3 = <FlSpot>[];

  for(int i = 0; i<29; i++){
    spotsGr3.add(FlSpot(i.toDouble(), (dateTotalCaseList[28-i]/1000000 - 453)/12));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '465.0M';
            case 3:
              return '489.0M';
            case 5:
              return '513.0M';
            case 7:
              return '537.0M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[28].substring(5);
            case 7:
              return dateList[21].substring(5);
            case 14:
              return dateList[14].substring(5);
            case 21:
              return dateList[7].substring(5);
            case 28:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 28,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr3,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
            show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 2,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}

LineChartData graph8() {
  List<Color> colors = [const Color(0xff49B7Eb)];
  List<FlSpot> spotsGr4 = <FlSpot>[];

  for(int i = 0; i<29; i++){
    spotsGr4.add(FlSpot(i.toDouble(), (dateNewCaseList[28-i]/1000000 - 1.1)/0.3));
  }

  return LineChartData(
    gridData: FlGridData(
      show: true,
      drawVerticalLine: false,
    ),
    titlesData: FlTitlesData(
      show: true,
      leftTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
          color: Color(0xff000000),
          fontWeight: FontWeight.normal,
          fontSize: 11,
        ),
        getTitles: (val){
          switch(val.toInt()){
            case 1:
              return '1.4M';
            case 3:
              return '2.0M';
            case 5:
              return '2.6M';
            case 7:
              return '3.2M';
          }
          return '';
        },
        reservedSize: 36,
        margin: 8,
      ),
      bottomTitles: SideTitles(
        showTitles: true,
        textStyle: const TextStyle(
            color: Color(0xff000000),
            fontWeight: FontWeight.normal,
            fontSize: 11),
        getTitles: (value) {
          switch (value.toInt()) {
            case 0:
              return dateList[28].substring(5);
            case 7:
              return dateList[21].substring(5);
            case 14:
              return dateList[14].substring(5);
            case 21:
              return dateList[7].substring(5);
            case 28:
              return dateList[0].substring(5);
          }
          return '';
        },
        reservedSize: 36,
        margin: 5,
      ),
    ),
    borderData: FlBorderData(
        show: true,
        border: Border.all(width: 0)),
    minX: 0,
    maxX: 28,
    minY: 0,
    maxY: 8,
    lineBarsData: [
      LineChartBarData(
        spots: spotsGr4,
        isCurved: false,
        barWidth: 3,
        belowBarData: BarAreaData(show: false),
        dotData: FlDotData(
            show: true,
            getDotPainter: (spot, p, data, i){
              return FlDotCirclePainter(
                  radius: 2,
                  color: Color(0xff49B7Eb)
              );
            }
        ),
        colors: colors,
      ),
    ],
  );
}
