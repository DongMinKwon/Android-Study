package com.example.pa3_test;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
