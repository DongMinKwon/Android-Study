package com.example.week14_2017313135;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
