package com.example.week8assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
