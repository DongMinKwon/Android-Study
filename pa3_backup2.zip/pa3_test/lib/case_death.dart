import 'package:flutter/material.dart';
import 'package:pa3_test/main.dart';
import 'package:provider/provider.dart';


class CaseDeath extends StatelessWidget{
  final Map<String, String> arg;
  Widget textview = Text("hello world");
  int i = 0;
  CaseDeath(this.arg);

  void setText(){
    if(this.i == 0){
      textview = Text("Good!");
      i = 1 - i;
    }
  }

  @override
  Widget build(BuildContext context){

    return Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              textview,
              ElevatedButton(onPressed: setText, child: Text("click"))
            ],
          )
        ),
    );
  }
}