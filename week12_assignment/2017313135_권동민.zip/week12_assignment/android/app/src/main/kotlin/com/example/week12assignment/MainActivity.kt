package com.example.week12assignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
