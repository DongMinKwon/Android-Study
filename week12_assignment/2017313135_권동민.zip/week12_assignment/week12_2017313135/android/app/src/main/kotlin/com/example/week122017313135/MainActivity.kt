package com.example.week122017313135

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
